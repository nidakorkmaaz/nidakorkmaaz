var erkek=document.getElementById("erkek");
var kadın=document.getElementById("kadın");
var button=document.getElementById("btn1");

var sayı=0;



  function Selam() {
    document.getElementById("kadın").disabled = true;
    
  }